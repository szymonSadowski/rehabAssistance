# rehabAssistance
Całość aplikacji można znaleźc na githubie : https://github.com/szymonSadowski/rehabAssistance
Z powodów ograniczeń rozmiarów paczki nie można zamieścić jej całej na platformie moodle
Brak koniecznych do uruchomienia aplikacji modeli